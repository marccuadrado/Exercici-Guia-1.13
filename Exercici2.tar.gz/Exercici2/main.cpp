#include<string.h>
#include<stdio.h>
#include<stdlib.h>




using namespace std;

int main (int argc, char *argv[]) {
	char peticion [100];
	char resultado [100];
	
	strcpy (peticion, "Marc/20/Juan/12/Maria/22/Pep/19");
	char nombre [20];
	int edad;
	
	char *p = strtok (peticion, "/");
	while (p!=NULL)
	{
		strcpy (nombre, p);
		p = strtok (NULL, "/");
		edad = atoi (p);
		
		if (edad > 18);
			sprintf (resultado, "%s%s*%d-", resultado, nombre, edad);
		
		p = strtok (NULL, "/");
		
		
			
	}
		resultado [strlen (resultado) -1] = '\0';
		printf ("Resultado: %s\n", resultado);
}
